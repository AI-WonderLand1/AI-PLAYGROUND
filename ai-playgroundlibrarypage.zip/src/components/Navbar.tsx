import React from 'react';
import { 
  Workflow, 
  Layers, 
  Code2, 
  Download, 
  Sparkles, 
  ExternalLink,
  BookOpen,
  Plus
} from 'lucide-react';
import { WorkflowTemplate } from '../types';

interface NavbarProps {
  currentView: 'library' | 'detail' | 'canvas' | 'types_docs';
  setCurrentView: (view: 'library' | 'detail' | 'canvas' | 'types_docs') => void;
  activeTemplate: WorkflowTemplate | null;
  totalTemplates: number;
  onNewBlankWorkflow?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  activeTemplate,
  totalTemplates,
  onNewBlankWorkflow
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('library')}
            className="flex items-center gap-2.5 group text-left cursor-pointer focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-600 via-rose-500 to-amber-500 flex items-center justify-center text-white shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
              <Workflow className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 dark:text-white text-lg tracking-tight">n8n Workflow Hub</span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-orange-100 dark:bg-orange-950/80 text-orange-700 dark:text-orange-300 border border-orange-200 dark:border-orange-800">
                  Pro Library
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
                {totalTemplates} Production Templates & Interactive Canvas
              </p>
            </div>
          </button>
        </div>

        {/* View Switcher Tabs */}
        <nav className="flex items-center p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl border border-slate-200/80 dark:border-slate-700">
          <button
            onClick={() => setCurrentView('library')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              currentView === 'library' || currentView === 'detail'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4 text-orange-500" />
            <span>Templates</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-mono">
              {totalTemplates}
            </span>
          </button>

          <button
            onClick={() => setCurrentView('canvas')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              currentView === 'canvas'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Workflow className="w-4 h-4 text-rose-500" />
            <span>Visual Canvas</span>
            {activeTemplate && (
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title={`Loaded: ${activeTemplate.name}`} />
            )}
          </button>

          <button
            onClick={() => setCurrentView('types_docs')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              currentView === 'types_docs'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Code2 className="w-4 h-4 text-indigo-500" />
            <span className="hidden sm:inline">TypeScript & Schema</span>
            <span className="sm:hidden">Types</span>
          </button>
        </nav>

        {/* Action Button */}
        <div className="flex items-center gap-2">
          {onNewBlankWorkflow && (
            <button
              onClick={onNewBlankWorkflow}
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-orange-500" />
              <span>Blank Canvas</span>
            </button>
          )}

          <a
            href="https://n8n.io"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-orange-500 to-rose-600 hover:from-orange-600 hover:to-rose-700 rounded-lg shadow-sm shadow-orange-500/20 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">n8n Official</span>
            <ExternalLink className="w-3 h-3 opacity-80" />
          </a>
        </div>
      </div>
    </header>
  );
};
