import React, { useEffect, useState, useRef } from 'react';
import { 
  Search, 
  X, 
  SlidersHorizontal, 
  Sparkles, 
  Layers,
  ArrowUpDown,
  Bot,
  Share2,
  Users,
  ShoppingBag,
  Terminal,
  MessageSquare,
  BookOpen,
  RotateCcw,
  Check,
  ChevronDown,
  Flame,
  Zap,
  Clock,
  SortAsc
} from 'lucide-react';
import { TemplateCategory, WorkflowTemplate } from '../types';
import { CATEGORIES } from '../data/templates';

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: TemplateCategory;
  setSelectedCategory: (cat: TemplateCategory) => void;
  sortBy: 'popular' | 'nodes' | 'name' | 'fastest';
  setSortBy: (sort: 'popular' | 'nodes' | 'name' | 'fastest') => void;
  totalFilteredCount: number;
  totalAllCount: number;
  onResetFilters: () => void;
  allTemplates: WorkflowTemplate[];
}

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({
  isOpen,
  onClose,
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  sortBy,
  setSortBy,
  totalFilteredCount,
  totalAllCount,
  onResetFilters,
  allTemplates
}) => {
  const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false);
  const sortDropdownRef = useRef<HTMLDivElement>(null);

  // Close sort dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (sortDropdownRef.current && !sortDropdownRef.current.contains(event.target as Node)) {
        setIsSortDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Close drawer on Escape key (mobile overlay fix)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isSortDropdownOpen) {
          setIsSortDropdownOpen(false);
        } else if (isOpen) {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isSortDropdownOpen, onClose]);

  const SORT_OPTIONS: { id: 'popular' | 'nodes' | 'name' | 'fastest'; label: string; shortLabel: string; icon: React.ReactNode }[] = [
    { id: 'popular', label: 'Most Popular & Stars', shortLabel: 'Popular', icon: <Flame className="w-3.5 h-3.5 text-amber-400" /> },
    { id: 'nodes', label: 'Most Nodes (Largest)', shortLabel: 'Nodes', icon: <Layers className="w-3.5 h-3.5 text-cyan-400" /> },
    { id: 'fastest', label: 'Fastest Setup (~5m)', shortLabel: 'Fast', icon: <Clock className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'name', label: 'Alphabetical (A-Z)', shortLabel: 'A-Z', icon: <SortAsc className="w-3.5 h-3.5 text-pink-400" /> }
  ];

  const currentSortObj = SORT_OPTIONS.find(s => s.id === sortBy) || SORT_OPTIONS[0];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'AI Agents & LLMs':
        return <Bot className="w-4 h-4 text-pink-400" />;
      case 'Social Media & Video':
        return <Share2 className="w-4 h-4 text-purple-400" />;
      case 'Customer Support & Sales':
        return <Users className="w-4 h-4 text-cyan-400" />;
      case 'DevOps & APIs':
        return <Terminal className="w-4 h-4 text-emerald-400" />;
      case 'RAG & Knowledge Base':
        return <Zap className="w-4 h-4 text-amber-400" />;
      case 'Productivity & Office':
        return <MessageSquare className="w-4 h-4 text-indigo-400" />;
      case 'Tutorials & Essentials':
        return <BookOpen className="w-4 h-4 text-rose-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-orange-400" />;
    }
  };

  const getCategoryCount = (cat: string) => {
    if (cat === 'All') return allTemplates.length;
    return allTemplates.filter(t => t.category === cat).length;
  };

  const hasActiveFilters =
    searchQuery !== '' ||
    selectedCategory !== 'All' ||
    sortBy !== 'popular';

  return (
    <>
      {/* Mobile Drawer Overlay Backdrop - Explicit z-40 and click-outside handler */}
      {isOpen && (
        <div 
          id="drawer-backdrop"
          onClick={onClose}
          className="fixed inset-0 bg-black/75 backdrop-blur-sm z-40 lg:hidden transition-opacity cursor-pointer animate-in fade-in duration-200"
          aria-hidden="true"
        />
      )}

      {/* Sidebar / Drawer Container */}
      <aside
        id="sidebar-categories-drawer"
        className={`fixed lg:sticky top-0 lg:top-16 left-0 z-50 lg:z-30 h-screen lg:h-[calc(100vh-4rem)] w-80 max-w-[85vw] bg-slate-900/95 lg:bg-slate-950/90 backdrop-blur-xl border-r border-white/10 shadow-2xl flex flex-col transition-transform duration-300 ease-in-out shrink-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Drawer Header with Title and Close on Mobile */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-pink-950/30 via-purple-950/30 to-indigo-950/30">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-tiedye-gradient flex items-center justify-center text-white shadow-md shadow-purple-500/20">
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </div>
            <div>
              <h2 className="font-extrabold text-sm text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-300 to-cyan-300 uppercase tracking-wider">
                Wonder Explorer
              </h2>
              <p className="text-[10px] text-slate-400 font-medium">Search & Curated Categories</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {hasActiveFilters && (
              <button
                id="drawer-reset-button"
                onClick={onResetFilters}
                title="Reset all filters"
                className="text-[11px] text-pink-400 hover:text-pink-300 flex items-center gap-1 px-2 py-1 rounded-lg bg-pink-500/10 border border-pink-500/20 hover:bg-pink-500/20 transition-all cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
            <button
              id="drawer-close-button"
              onClick={onClose}
              className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content inside Drawer */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
          {/* SEARCH BAR WITH INTEGRATED SORT FILTER */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5 text-pink-400" />
                <span>Search & Filter</span>
              </label>
              <span className="text-[10px] text-slate-400 font-mono">
                {totalFilteredCount} of {totalAllCount}
              </span>
            </div>

            {/* Unified Sleek Search + Integrated Sort Container */}
            <div className="relative rounded-2xl bg-slate-900/90 border border-white/15 shadow-inner focus-within:border-pink-500/60 focus-within:ring-2 focus-within:ring-pink-500/20 transition-all p-1.5 space-y-1.5">
              {/* Top Row: Search Input */}
              <div className="relative flex items-center">
                <Search className="w-4 h-4 absolute left-2.5 text-pink-400/80 pointer-events-none" />
                <input
                  id="drawer-search-input"
                  type="text"
                  placeholder="Search 50+ templates..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-7 py-1.5 bg-transparent text-white placeholder-slate-500 text-xs focus:outline-none"
                />
                {searchQuery && (
                  <button
                    id="drawer-search-clear"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-1.5 text-slate-400 hover:text-white p-1 rounded-md hover:bg-white/10 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Bottom Row: Integrated Sort Filter Inside Search Bar */}
              <div className="pt-1.5 border-t border-white/10 flex items-center justify-between" ref={sortDropdownRef}>
                <span className="text-[10px] text-slate-400 flex items-center gap-1 pl-1">
                  <ArrowUpDown className="w-3 h-3 text-cyan-400" />
                  <span>Sort by:</span>
                </span>

                <div className="relative">
                  <button
                    id="drawer-sort-inline-button"
                    onClick={() => setIsSortDropdownOpen(prev => !prev)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 hover:from-purple-500/30 hover:to-pink-500/30 text-white text-[11px] font-semibold border border-purple-500/30 shadow-xs transition-all cursor-pointer"
                  >
                    {currentSortObj.icon}
                    <span>{currentSortObj.shortLabel}</span>
                    <ChevronDown className={`w-3 h-3 text-slate-300 transition-transform ${isSortDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Groovy Sort Dropdown Popover */}
                  {isSortDropdownOpen && (
                    <div className="absolute right-0 top-full mt-1.5 w-48 rounded-xl bg-slate-900/95 border border-purple-500/30 shadow-2xl p-1.5 z-50 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
                        Select Sort Order
                      </div>
                      {SORT_OPTIONS.map(opt => {
                        const isSelected = sortBy === opt.id;
                        return (
                          <button
                            key={opt.id}
                            onClick={() => {
                              setSortBy(opt.id);
                              setIsSortDropdownOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all text-left cursor-pointer ${
                              isSelected
                                ? 'bg-gradient-to-r from-pink-500/30 to-purple-500/30 text-white font-semibold border border-pink-500/40'
                                : 'text-slate-300 hover:text-white hover:bg-white/10'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              {opt.icon}
                              <span>{opt.label}</span>
                            </div>
                            {isSelected && <Check className="w-3.5 h-3.5 text-pink-400" />}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {searchQuery && (
              <p className="text-[11px] text-pink-300/90 mt-1.5 px-1 font-medium flex items-center gap-1">
                <span>✦</span>
                <span>Found {totalFilteredCount} matching workflow{totalFilteredCount !== 1 ? 's' : ''}</span>
              </p>
            )}
          </div>

          {/* GROOVY CATEGORIES LIST */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <label className="text-[11px] font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-300 to-pink-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Categories</span>
              </label>
              <span className="text-[10px] text-purple-300 font-mono px-2 py-0.5 rounded-full bg-purple-500/10 border border-purple-500/20">
                {CATEGORIES.length - 1} Channels
              </span>
            </div>

            <div className="space-y-1.5">
              {CATEGORIES.map(cat => {
                const isSelected = selectedCategory === cat;
                const count = getCategoryCount(cat);

                return (
                  <button
                    key={cat}
                    id={`drawer-category-${cat.replace(/[^a-z0-9]/gi, '-').toLowerCase()}`}
                    onClick={() => {
                      setSelectedCategory(cat as TemplateCategory);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all text-left cursor-pointer group relative overflow-hidden ${
                      isSelected
                        ? 'bg-gradient-to-r from-pink-500/25 via-purple-500/25 to-cyan-500/25 text-white border border-pink-500/50 shadow-lg shadow-purple-500/10'
                        : 'text-slate-300 hover:text-white hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    {/* Subtle psychedelic edge glow when selected */}
                    {isSelected && (
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-tiedye-gradient rounded-r" />
                    )}

                    <div className="flex items-center gap-2.5 truncate pl-1">
                      <span className={`p-1.5 rounded-xl transition-all ${
                        isSelected 
                          ? 'bg-tiedye-gradient text-white shadow-sm shadow-pink-500/30' 
                          : 'bg-slate-800 text-slate-400 group-hover:text-slate-200 group-hover:bg-slate-700'
                      }`}>
                        {getCategoryIcon(cat)}
                      </span>
                      <span className="truncate">{cat}</span>
                    </div>

                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full transition-all ${
                        isSelected
                          ? 'bg-pink-500 text-white font-bold shadow-xs'
                          : 'bg-slate-800 text-slate-400 group-hover:bg-slate-700 group-hover:text-slate-200'
                      }`}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Drawer Footer with Groovy Badge */}
        <div className="p-4 border-t border-white/10 bg-slate-950/70 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Showing {totalFilteredCount} templates</span>
          </div>
          {hasActiveFilters && (
            <button
              onClick={onResetFilters}
              className="text-pink-400 hover:text-pink-300 font-semibold underline text-xs cursor-pointer"
            >
              Clear Filters
            </button>
          )}
        </div>
      </aside>
    </>
  );
};
